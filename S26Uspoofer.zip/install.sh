#########################################
# Magisk Module Installer Configuration #
#########################################

# Required flags for Magisk installer
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

# Extract module files into $MODPATH
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" -x 'META-INF/*' 'install.sh' -d "$MODPATH" >&2
  
# Set permissions for installed files
set_permissions() {
  # Default: directories 0755, files 0644
  set_perm_recursive "$MODPATH" 0 0 0755 0644
}