#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done

resetprop gsm.version.baseband "S948BXXU4CZJ1,S948BXXU4CZJ1"
resetprop ril.product_code "SM-S948BZVAEUX"
